package com.corejava.Object;

public class Object {

	public static void main(String[] args) {
		
		Hello hello = new Hello();
		hello.show();
		

	}

}

class Hello
{
	void show()
	{
		System.out.println("First Object");
	}
}