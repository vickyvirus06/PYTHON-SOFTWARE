/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author vickyvirus
 */

import com.ziacsoft.home.Home;
public class Main {
    
    public static void main(String [] args)
    {
        Home home = new Home();
        home.setVisible(true);
    }
    
}
