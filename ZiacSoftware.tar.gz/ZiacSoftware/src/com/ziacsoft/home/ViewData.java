/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ziacsoft.home;

import java.awt.ScrollPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import org.jdesktop.swingx.JXTable;

/**
 *
 * @author vickyvirus
 */
public class ViewData extends JFrame{
    
    public ViewData(String[][] Data)
    {
        String[] Columns={"Sr","Name","Id"};
        JFrame frame = new JFrame();
        frame.setSize(600, 800);
        JXTable table = new JXTable(Data,Columns);
        table.putClientProperty(JXTable.USE_DTCR_COLORMEMORY_HACK, Boolean.FALSE);      //Disable strange hack that overwrite JLabel's setBackground() by a Highlighter color
        table.setColumnControlVisible(false);
        table.setEditable(false);
        table.setSortable(false);
        table.setRolloverEnabled(false);
        table.packAll();
        table.setHorizontalScrollEnabled(true);
        JScrollPane scrollpane = new JScrollPane(table); 
        
        frame.add(scrollpane);
        frame.setVisible(true);
        
    }
    
}
