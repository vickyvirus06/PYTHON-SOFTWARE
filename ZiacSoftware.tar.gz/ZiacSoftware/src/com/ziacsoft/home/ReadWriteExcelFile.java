package com.ziacsoft.home;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Vector;
import javax.swing.JOptionPane;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadWriteExcelFile {
    
    
    
    private static Vector dataTemp = new Vector();
    private static Vector columns = new Vector();
    private static Vector data = new Vector();

	/*public static void readXLSFile() throws IOException
	{
		InputStream ExcelFileToRead = new FileInputStream("C:/Test.xls");
		HSSFWorkbook wb = new HSSFWorkbook(ExcelFileToRead);

		HSSFSheet sheet=wb.getSheetAt(0);
		
		Iterator rows = sheet.rowIterator();
                
    

		while (rows.hasNext())
		{
			row=(HSSFRow) rows.next();
			Iterator cells = row.cellIterator();
			
			while (cells.hasNext())
			{
				cell=(HSSFCell) cells.next();
		
				if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING)
				{
					System.out.print(cell.getStringCellValue()+" ");
				}
				else if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
				{
					System.out.print(cell.getNumericCellValue()+" ");
				}
				else
				{
					//U Can Handel Boolean, Formula, Errors
				}
			}
			System.out.println();
		}
	
	} */
	
	
	public void readXLSXFile(File file) throws IOException
	{
                JOptionPane.showMessageDialog(null,
                            "Hello");
		InputStream ExcelFileToRead = new FileInputStream(file);
		XSSFWorkbook  wb = new XSSFWorkbook(ExcelFileToRead);
		
		XSSFWorkbook test = new XSSFWorkbook(); 
		
		XSSFSheet sheet = wb.getSheetAt(0);
		int noOfColumns = sheet.getRow(0).getLastCellNum();
                int noOfRows = sheet.getLastRowNum()+1;
                String[][] Data = new String[noOfRows][noOfColumns];
		for(int i=0;i<noOfRows;i++)
                {
                    for(int j=0;j<noOfColumns;j++)
                    {
                        Data[i][j]= (wb.getSheetAt(0).getRow(i).getCell(j)).toString();
                        
                        
                        
                    }
                }
                ViewData view = new ViewData(Data);
                
                
        }
}
 


		
	
	
	
	
	



