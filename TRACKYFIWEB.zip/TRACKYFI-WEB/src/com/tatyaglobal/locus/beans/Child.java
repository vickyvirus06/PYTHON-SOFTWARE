package com.tatyaglobal.locus.beans;

public class Child {
	String cName,Latitude,tMobileNum,Longitude,TS,Battery,Speed;
	String pID,pMobile,tID,pName;
	int cID;
	
	public String jsonString() {
		return "{\"Child\": {\"cID\":\""+cID+"\",\"cName\":\""+cName+"\",\"Lat\": \""+Latitude+ "\", \"Lon\": \""+ Longitude
				+ "\"}";
	}
	public String jsonString1() {
		return "{\"TS\": \""+TS.substring(0, 19)+ "\",\"Lat\": \""+Latitude+ "\", \"Lon\": \""+ Longitude+ "\",\"Battery\": \""+Battery+ "\", \"Speed\": \""+ Speed+ "\"}";
	}
	
	
	public Child(String latitude, String longitude,  String battery,
			String speed,String tS) {
		super();
		Latitude = latitude;
		Longitude = longitude;
		Battery = battery;
		Speed = speed;
		TS = tS;
	}

	public Child(int cID,String latitude, String longitude) {
		super();
		this.cID = cID;
		Latitude = latitude;
		Longitude = longitude;
		
	}
	
	public Child(int cID,String cName, String tMobileNum,String pName,String pMobile) {
	
		this.cID = cID;
		this.cName = cName;
		this.tMobileNum = tMobileNum;
		this.pName = pName;
		this.pMobile = pMobile;
	
	}

	public String jsonString2() {
		return "{\"ID\": \""+cID + "\", \"childName\": \""+ cName+"\", \"Phone\": \""+ tMobileNum+ "\"";
	}
	
	public String jsonString3() {
		return "{\"TS\": \""+TS.substring(0, 19)+ "\",\"Lat\": \""+Latitude+ "\", \"Lon\": \""+ Longitude+ "\",\"Battery\": \""+Battery+ "\", \"Speed\": \""+ Speed+ "\"}";
	}

	
	
	public String getpID() {
		return pID;
	}
	public void setpID(String pID) {
		this.pID = pID;
	}
	public String getpMobile() {
		return pMobile;
	}
	public void setpMobile(String pMobile) {
		this.pMobile = pMobile;
	}
	public String gettID() {
		return tID;
	}
	public void settID(String tID) {
		this.tID = tID;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String gettMobileNum() {
		return tMobileNum;
	}

	public void settMobileNum(String tMobileNum) {
		this.tMobileNum = tMobileNum;
	}

	public String getLatitude() {
		return Latitude;
	}

	public void setLatitude(String latitude) {
		Latitude = latitude;
	}

	public String getLongitude() {
		return Longitude;
	}

	public void setLongitude(String longitude) {
		Longitude = longitude;
	}

	public String getTS() {
		return TS;
	}

	public void setTS(String tS) {
		TS = tS;
	}

	public String getBattery() {
		return Battery;
	}

	public void setBattery(String battery) {
		Battery = battery;
	}

	public String getSpeed() {
		return Speed;
	}

	public void setSpeed(String speed) {
		Speed = speed;
	}

	public int getcID() {
		return cID;
	}

	public void setcID(int cID) {
		this.cID = cID;
	}
	
	
}
