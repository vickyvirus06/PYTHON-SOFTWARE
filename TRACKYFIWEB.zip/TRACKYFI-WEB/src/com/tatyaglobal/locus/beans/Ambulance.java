package com.tatyaglobal.locus.beans;

public class Ambulance {

	String LicenseNo, tId, MobileNo, Lat ,Lon, TS;

	public Ambulance(String trackerId, String licenseNo,  String tmobileNo, String lat,
			String lon, String stTs) {
		super();
		this.tId = trackerId;
		LicenseNo = licenseNo;
		MobileNo = tmobileNo;
		Lat = lat;
		Lon = lon;
		TS = stTs;
	}
	
	public Ambulance(String trackerId, String licenseNo,  String tmobileNo) {
		super();
		this.tId = trackerId;
		LicenseNo = licenseNo;
		MobileNo = tmobileNo;
	}
	
	public Ambulance(String trackerId,String lat,
			String lon, String stTs) {
		super();
		this.tId = trackerId;
		Lat = lat;
		Lon = lon;
		TS = stTs;
	}



	public String getLicenseNo() {
		return LicenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		LicenseNo = licenseNo;
	}

	public String gettId() {
		return tId;
	}

	public void settId(String tId) {
		this.tId = tId;
	}

	public String getMobileNo() {
		return MobileNo;
	}

	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}

	public String getLat() {
		return Lat;
	}

	public void setLat(String lat) {
		Lat = lat;
	}

	public String getLon() {
		return Lon;
	}

	public void setLon(String lon) {
		Lon = lon;
	}

	public String getTS() {
		return TS;
	}

	public void setTS(String tS) {
		TS = tS;
	}
	
}
