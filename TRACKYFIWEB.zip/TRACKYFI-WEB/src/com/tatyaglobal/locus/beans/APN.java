package com.tatyaglobal.locus.beans;

public class APN {

String country,operator,apn;
	
	public APN(String country) {
		super();
		this.country = country;
	}

	public APN(String country, String operator) {
		super();
		this.country = country;
		this.operator = operator;
	}

	public APN(String country, String operator, String apn) {
		super();
		this.country = country;
		this.operator = operator;
		this.apn = apn;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getApn() {
		return apn;
	}

	public void setApn(String apn) {
		this.apn = apn;
	}
}
