package com.tatyaglobal.locus.beans;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Work {

	public static void main(String... args)
	{
		String remove = "how u";
		List<String> mylist = new ArrayList<String>();
		mylist.add("hello");
		mylist.add("how u");
		mylist.add("bye");
		System.out.println("before remove");
		System.out.println(mylist);
		Iterator<String> itr = mylist.iterator();
		while(itr.hasNext())
		{
			if(remove.equals(itr.next()))
			{
				itr.remove();
			}          
		}
		System.out.println("after remove");
		System.out.println(mylist);
		
	}
	
}
