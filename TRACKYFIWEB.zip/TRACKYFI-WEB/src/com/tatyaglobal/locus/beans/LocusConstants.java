package com.tatyaglobal.locus.beans;

public interface LocusConstants {
	//
	// Used in LoginSrv
	// Error Responses
	//
	public static final int INVALID_LOGIN = -10;
	public static final int TECHNICAL_PROBLEM = -11;
	
	public static final int LOCATION_POINTS_DEFAULT_LIMIT = 1;		//used in DBManager class
	public static final int LAST_LOCATION_DEFAULT_LIMIT = 1;
	public static final int LAST_LOCATION_LIMIT = 1;//to calculate zone taking only last lat,lon[used in ambulance service]
	public static final int LOCATION_BETWEEN_TWO_POINTS_DEFAULT_LIMIT = 20;
	
	public static final int LAST_BATTERY_SPPED_DEFAULT_LIMIT = 1;

}
