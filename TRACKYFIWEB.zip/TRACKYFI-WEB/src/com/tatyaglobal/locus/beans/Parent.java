package com.tatyaglobal.locus.beans;

public class Parent {

private String pID, pName,pMobile1,pMobile2,pEmail1,pEmail2,pPhoto,pIDcard,pAddress,pCity,pState,pCode,pAddrLat,pAddrLon;

	
	public Parent(String pName, String pMobile1, String pMobile2, String pEmail1,
		String pEmail2, String pPhoto, String pIDcard, String pAddress,
		String pCity, String pState, String pCode, String pAddrLat,
		String pAddrLon) {
	super();
	this.pName = pName;
	this.pMobile1 = pMobile1;
	this.pMobile2 = pMobile2;
	this.pEmail1 = pEmail1;
	this.pEmail2 = pEmail2;
	this.pPhoto = pPhoto;
	this.pIDcard = pIDcard;
	this.pAddress = pAddress;
	this.pCity = pCity;
	this.pState = pState;
	this.pCode = pCode;
	this.pAddrLat = pAddrLat;
	this.pAddrLon = pAddrLon;
    }

	public Parent(String pID, String pName, String pMobile1, String pMobile2,
			String pEmail1, String pEmail2, String pPhoto, String pIDcard,
			String pAddress, String pCity, String pState, String pCode,
			String pAddrLat, String pAddrLon) {
		super();
		this.pID = pID;
		this.pName = pName;
		this.pMobile1 = pMobile1;
		this.pMobile2 = pMobile2;
		this.pEmail1 = pEmail1;
		this.pEmail2 = pEmail2;
		this.pPhoto = pPhoto;
		this.pIDcard = pIDcard;
		this.pAddress = pAddress;
		this.pCity = pCity;
		this.pState = pState;
		this.pCode = pCode;
		this.pAddrLat = pAddrLat;
		this.pAddrLon = pAddrLon;
	}

	public String getpID() {
		return pID;
	}

	public void setpID(String pID) {
		this.pID = pID;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public String getpMobile1() {
		return pMobile1;
	}

	public void setpMobile1(String pMobile1) {
		this.pMobile1 = pMobile1;
	}

	public String getpMobile2() {
		return pMobile2;
	}

	public void setpMobile2(String pMobile2) {
		this.pMobile2 = pMobile2;
	}

	public String getpEmail1() {
		return pEmail1;
	}

	public void setpEmail1(String pEmail1) {
		this.pEmail1 = pEmail1;
	}

	public String getpEmail2() {
		return pEmail2;
	}

	public void setpEmail2(String pEmail2) {
		this.pEmail2 = pEmail2;
	}

	public String getpPhoto() {
		return pPhoto;
	}

	public void setpPhoto(String pPhoto) {
		this.pPhoto = pPhoto;
	}

	public String getpIDcard() {
		return pIDcard;
	}

	public void setpIDcard(String pIDcard) {
		this.pIDcard = pIDcard;
	}

	public String getpAddress() {
		return pAddress;
	}

	public void setpAddress(String pAddress) {
		this.pAddress = pAddress;
	}

	public String getpCity() {
		return pCity;
	}

	public void setpCity(String pCity) {
		this.pCity = pCity;
	}

	public String getpState() {
		return pState;
	}

	public void setpState(String pState) {
		this.pState = pState;
	}

	public String getpCode() {
		return pCode;
	}

	public void setpCode(String pCode) {
		this.pCode = pCode;
	}

	public String getpAddrLat() {
		return pAddrLat;
	}

	public void setpAddrLat(String pAddrLat) {
		this.pAddrLat = pAddrLat;
	}

	public String getpAddrLon() {
		return pAddrLon;
	}

	public void setpAddrLon(String pAddrLon) {
		this.pAddrLon = pAddrLon;
	}
	
}
