package com.tatyaglobal.locus.beans;

public class SafeZone {
	
	int cID,Radius;
	private String Lat,Lon;
	
	public String jsonString1() {
		return "{\"Lat\": \""+Lat + "\", \"Lon\":\""+Lon+"\", \"Radius\":\""+Radius+"\"} ";
	}
	public SafeZone(int cID, String lat, String lon, int radius) {
		this.cID=cID;
		this.Lat=lat;
		this.Lon=lon;
		this.Radius=radius;
	}
	
	public SafeZone() {
		// TODO Auto-generated constructor stub
	}

	public int getcID() {
		return cID;
	}
	
	public void setcID(int cID) {
		this.cID = cID;
	}
	
	public int getRadius() {
		return Radius;
	}
	
	public void setRadius(int radius) {
		Radius = radius;
	}
	
	public String getLat() {
		return Lat;
	}
	
	public void setLat(String lat) {
		Lat = lat;
	}
	
	public String getLon() {
		return Lon;
	}
	
	public void setLon(String lon) {
		Lon = lon;
	}
	
	

}
