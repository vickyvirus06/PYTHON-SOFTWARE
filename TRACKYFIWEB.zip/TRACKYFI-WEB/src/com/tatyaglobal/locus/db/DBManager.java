package com.tatyaglobal.locus.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.tatyaglobal.locus.beans.*;

public class DBManager implements LocusConstants {

	public static String classname = "DBManager";

	// Maximum number of Connections provided for the application
	private static final int MAX_CONNECTIONS = 10;
	private static final int WARN_LOW_CONNECTIONS = 2;

	// TODO: create a variable to read the DB information from a property file
	// instead of DEFAULT VALUES

	// DEFAULT VALUES for database connection
	public static final String DEFAULT_DB_IP = "localhost";
	public static final String DEFAULT_DB_PORT = "4306";
	public static final String DEFAULT_DB = "mylocus";
	public static final String DEFAUlT_DB_USER = "root";
	public static final String DEFAUlT_DB_PWD = "Ziac1993$";
	public static final String DEFAUlT_DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DEFAUlT_DB_TYPE = "jdbc:mysql";
	public static final String DEFAUlT_DB_URL_STRING = "jdbc:mysql://localhost:4306/mylocus?autoReconnect=true&useSSL=false";

	
			
	// variables for the database
	protected String driver;
	protected String url;
	protected String user;
	protected String pwd;
	protected int poolSize;

	// DBManager is a Singleton; hence the private static
	private static DBManager dbm;

	// Log4J instance for logging
	public Logger logger = null;

	// Vector of DB Connections
	protected Vector<Connection> pool = new Vector<Connection>();

	// Constructor for DBManager
	private DBManager(String driver, String url, String user, String pwd,
			int poolSize) {
		this.driver = driver;
		this.url = url;
		this.user = user;
		this.pwd = pwd;
		this.poolSize = poolSize;
	}

	// Constructor for DBManager
	private DBManager() {
		this.driver = DEFAUlT_DB_DRIVER;
		this.url = DEFAUlT_DB_URL_STRING;
		this.user = DEFAUlT_DB_USER;
		this.pwd = DEFAUlT_DB_PWD;
		this.poolSize = MAX_CONNECTIONS;
	}

	// public method to create/ return a single instance of the DBManager
	public static DBManager getInstance() {
		// If DBMAnager instance doesn't exist, then this is the first time it's
		// been called.
		// create a new DBManager and return the object
		if (dbm == null) {
			dbm = new DBManager(); // no parameters in the constructor invoke:
									// using DEFAULT values
			dbm.init();
		} else {
			// DBManager already exists, return with the object
			return dbm;
		}

		return dbm;
	}

	// Method to initialize the Logger and Create the Connection Pool
	public void init() {
		// create the logger

		logger = Logger.getRootLogger();

		// load the database driver
		try {
			Class.forName(driver);

		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}

		Connection con = null;
		// Create the connection pool
		for (int i = 0; i < poolSize; i++) {
			con = null;
			try {
				// create a connection and add it to the connection pool
				con = openConnection();
				if (con != null) {
					pool.add(con);
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}

		}
	}

	// create a new connection to the database
	private Connection openConnection() throws SQLException {
		
		return DriverManager.getConnection(url, user, pwd);

	}

	// close a connection to the database
	private void closeConnection(Connection con) throws SQLException {
		if (con != null) {
			con.close();
			con = null;

		}
	}

	// method to get a connection from the connection pool for working
	public Connection checkOut() {
		String methodName = "checkOut";

		Connection con = null;

		// get the connection at position 0 and remove it from the vector
		if (pool != null && pool.size() > 0) {
			//logInfo(methodName, "before removing connections" + pool.size());
			con = pool.remove(0);
			//logInfo(methodName, "after removing connections" + pool.size());

			// warn if the connection pool size reduces below 2 connections
			if (pool.size() < WARN_LOW_CONNECTIONS) {
				logger.info("connections are low");
			}

		} else {
			// connections dont exist, create a new DB connection and then
			// return that object
			try {
				con = openConnection();

			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return con;
	}

	// Checkin the connection after work
	public void checkIn(Connection con) {

		String methodName = "checkIn";

		if (con != null) {
			if (pool != null) {
				//logInfo(methodName, "before adding connections" + pool.size());
				pool.add(con);
				//logInfo(methodName, "after adding connections" + pool.size());
			}
		}
	}

	// Release all connections from the pool
	public void release() {
		Connection con = null;
		while (pool.size() > 0) {
			// System.out.println("release():: value of pool size="+pool.size());
			con = pool.remove(0);
			try {
				closeConnection(con);
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	// assumption is that uname is string value and not null
	public Login getLoginDetails(String mobile, String pwd) {

		String methodName = "getLoginDetails";
		logInfo(methodName, "entering with mobile=" + mobile + " and PWD="
				+ pwd);

		String query = "select * from mylocus.login_info where MobileNum=?";
		Login l = null;

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			con = this.checkOut();
			if (con == null) {
				System.out.println("null conn");
				return l;
			}
			ps = con.prepareStatement(query);
			ps.setString(1, mobile);
			System.out.println(ps);
			rs = ps.executeQuery();

			while (rs.next()) {
				if (rs.getString("pwd").equals(pwd)) {
					String userID = rs.getString("userID");
					l = new Login(mobile, pwd, userID);
					// logInfo(methodName, l.toString());
					// logInfo(methodName, l.jsonString());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				// ps.close();
			} catch (Exception fe) {
			}
			this.checkIn(con);
		}
		if (l != null) {
			// you can use loginfo in web service model only because
			// log4j.properties is present in the web-inf folder
			logInfo(methodName, "found login for " + mobile);
		} else {
			logInfo(methodName, "Could not find login info for " + mobile);
		}
		return l;
	}

	// getting child details by passing parent id
	public ArrayList<Child> getChildDetails(String pID) {
		String methodName = "getChildDetails";
		logInfo(methodName, "entered with parent id: " + pID);
		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;
		Child cb = null;

		String query = "SELECT child.cID,child.cName,trackerdevice.tMobileNumber,parent_info.pName1,parent_info.pMobile1 FROM mylocus.child INNER JOIN parent_child ON child.cID=parent_child.cID INNER JOIN trackerdevice ON trackerdevice.tID=child.tID INNER JOIN parent_info ON parent_info.pID=parent_child.pID WHERE parent_info.pID=?";
		ArrayList<Child> lst = new ArrayList<Child>();
		try {
			con = this.checkOut();
			if (con == null) {
				System.out.println("null conn");
			}
			ps = con.prepareStatement(query);
			ps.setString(1, pID);
			System.out.println(ps);
			rs = ps.executeQuery();
			while (rs.next() == true) {
				int id = rs.getInt("cID");
				String name = rs.getString("cName");
				String tmobile = rs.getString("tMobileNumber");
				String pName = rs.getString("pName1");
				String pMobile = rs.getString("pMobile1");

				cb = new Child(id, name, tmobile, pName, pMobile);
				lst.add(cb);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				// ps.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			this.checkIn(con);
		}
		if (cb != null) {
			logInfo(methodName, "found child details for parent id:" + pID);
		} else {
			logInfo(methodName, "could not found child details for parent id:"
					+ pID);
		}
		return lst;
	}

	// to get child locations
	// checking whether their is location for last 15 min in trackerlocation
	// table
	// if not check in incomplete_data table
	// if data in not there for last 15 min in both the tables then giving last
	// 10 records
	@SuppressWarnings("resource")
	public ArrayList<Child> getChildLatLon(int cid) {
		String methodName = "getChildLatLon";
		logInfo(methodName, "entered with child id: " + cid);
		ResultSet rs = null;
		PreparedStatement ps1 = null, ps2 = null, ps3 = null, ps4 = null;
		Connection con = null;
		String lat = "";
		String lon = "";
		String battery = "";
		String speed = "";
		String ts = null;

		String query1 = "SELECT lat,lon,battery,speed,CONVERT_TZ(ts,'+00:00','+05:30') AS ts FROM trackerlocation WHERE  TS BETWEEN DATE_SUB(NOW(), INTERVAL 60 MINUTE) AND NOW() AND tID IN(SELECT tID FROM child WHERE cID=?)";
		String query2 = "SELECT lat,lon,battery,speed,CONVERT_TZ(ts,'+00:00','+05:30') AS ts FROM incomplete_data WHERE  TS BETWEEN DATE_SUB(NOW(), INTERVAL 60 MINUTE) AND NOW() AND tID IN(SELECT tID FROM child WHERE cID=?)";
		String query3 = "SELECT lat,lon,battery,speed,CONVERT_TZ(ts,'+00:00','+05:30') AS ts FROM trackerlocation WHERE tID IN(SELECT tID FROM child WHERE cID=?) ORDER BY TS DESC LIMIT "
				+ LOCATION_POINTS_DEFAULT_LIMIT;
		String query4 = "SELECT lat,lon,battery,speed,CONVERT_TZ(ts,'+00:00','+05:30') AS ts FROM trackerlocation WHERE tID IN(SELECT tID FROM child WHERE cID=?) ORDER BY TS DESC LIMIT "
				+ LOCATION_POINTS_DEFAULT_LIMIT;
		ArrayList<Child> lst = new ArrayList<Child>();
		try {
			con = this.checkOut();

			ps1 = con.prepareStatement(query1);
			ps1.setInt(1, cid);
			System.out.println(ps1);
			rs = ps1.executeQuery();
			// System.out.println(rs);
			if (rs.next()) {
				logInfo(methodName, "found records for child id: " + cid);
				ps3 = con.prepareStatement(query3);
				ps3.setInt(1, cid);
				System.out.println(ps3);
				rs = ps3.executeQuery();

				while (rs.next() == true) {
					lat = rs.getString("Lat");
					lon = rs.getString("Lon");
					battery = rs.getString("Battery");
					speed = rs.getString("Speed");
					ts = rs.getString("ts");

					// we are re-arranging the timestamp for IST. adding 5:30
					// hours
					//
					/*
					 * Date date = sdf.parse(ts); calendar.setTime(date);
					 * 
					 * int month = calendar.get(Calendar.MONTH)+1; int day =
					 * calendar.get(Calendar.DATE); int year =
					 * calendar.get(Calendar.YEAR); int hour =
					 * calendar.get(Calendar.HOUR)+5; int min =
					 * calendar.get(Calendar.MINUTE)+30; int sec =
					 * calendar.get(Calendar.SECOND);
					 * 
					 * String date1 = ""; date1 += year;
					 * 
					 * if(month <=9){ date1 +="-0"+month; }else{ date1 +=
					 * "-"+month; } if(day <=9){ date1 +="-0"+day; }else{ date1
					 * += "-"+day; } date1 += " "; if(hour <=9){ date1
					 * +="0"+hour; }else{ date1 += ""+hour; }
					 * 
					 * if(min <=9){ date1 +=":0"+min; }else{ date1 += ":"+min; }
					 * 
					 * if(sec <=9){ date1 +=":0"+sec; }else{ date1 += ":"+sec; }
					 * 
					 * logInfo(methodName,"ts after adding: "+date1);
					 */

					Child c1 = new Child(lat, lon, battery, speed, ts);
					lst.add(c1);
				} // end of while
			} else {
				logInfo(methodName, "could not find records for child id: "
						+ cid + " for last 60min");
				ps2 = con.prepareStatement(query2);
				ps2.setInt(1, cid);
				System.out.println(ps2);
				rs = ps2.executeQuery();
				if (rs.next()) {
					logInfo(methodName,
							"device is on but lat and lon is 0 for child id: "
									+ cid);
					ps3 = con.prepareStatement(query3);
					ps3.setInt(1, cid);
					System.out.println(ps3);
					rs = ps3.executeQuery();
					while (rs.next() == true) {
						lat = rs.getString("Lat");
						lon = rs.getString("Lon");
						battery = rs.getString("Battery");
						speed = rs.getString("Speed");
						ts = rs.getString("ts");
						System.out.println("ts before adding: " + ts);
						// we are re-arranging the timestamp for IST. adding
						// 5:30 hours
						//
						/*
						 * Date date = sdf.parse(ts); calendar.setTime(date);
						 * 
						 * int month = calendar.get(Calendar.MONTH)+1; int day =
						 * calendar.get(Calendar.DATE); int year =
						 * calendar.get(Calendar.YEAR); int hour =
						 * calendar.get(Calendar.HOUR)+5; int min =
						 * calendar.get(Calendar.MINUTE)+30; int sec =
						 * calendar.get(Calendar.SECOND); String date1 = "";
						 * date1 += year;
						 * 
						 * if(month <=9){ date1 +="-0"+month; }else{ date1 +=
						 * "-"+month; } if(day <=9){ date1 +="-0"+day; }else{
						 * date1 += "-"+day; } date1 += " "; if(hour <=9){ date1
						 * +="0"+hour; }else{ date1 += ""+hour; }
						 * 
						 * if(min <=9){ date1 +=":0"+min; }else{ date1 +=
						 * ":"+min; }
						 * 
						 * if(sec <=9){ date1 +=":0"+sec; }else{ date1 +=
						 * ":"+sec; }
						 * 
						 * logInfo(methodName,"ts after adding: "+date1);
						 */

						Child c1 = new Child(lat, lon, battery, speed, ts);
						lst.add(c1);
					}// end of while
				} else {
					logInfo(methodName,
							"device is switched off so sending last 10 location for child id: "
									+ cid);
					ps4 = con.prepareStatement(query4);
					ps4.setInt(1, cid);
					System.out.println(ps4);
					rs = ps4.executeQuery();
					while (rs.next() == true) {
						lat = rs.getString("Lat");
						lon = rs.getString("Lon");
						battery = rs.getString("Battery");
						speed = rs.getString("Speed");
						ts = rs.getString("ts");

						// System.out.println("ts before adding: "+ts);
						// we are re-arranging the timestamp for IST. adding
						// 5:30 hours
						//
						/*
						 * Date date = sdf.parse(ts); calendar.setTime(date);
						 * 
						 * int month = calendar.get(Calendar.MONTH)+1; int day =
						 * calendar.get(Calendar.DATE); int year =
						 * calendar.get(Calendar.YEAR); int hour =
						 * calendar.get(Calendar.HOUR)+5; int min =
						 * calendar.get(Calendar.MINUTE)+30; int sec =
						 * calendar.get(Calendar.SECOND);
						 * 
						 * String date1 = ""; date1 += year;
						 * 
						 * if(month <=9){ date1 +="-0"+month; }else{ date1 +=
						 * "-"+month; } if(day <=9){ date1 +="-0"+day; }else{
						 * date1 += "-"+day; } date1 += " "; if(hour <=9){ date1
						 * +="0"+hour; }else{ date1 += ""+hour; }
						 * 
						 * if(min <=9){ date1 +=":0"+min; }else{ date1 +=
						 * ":"+min; }
						 * 
						 * if(sec <=9){ date1 +=":0"+sec; }else{ date1 +=
						 * ":"+sec; }
						 * 
						 * logInfo(methodName,"ts after adding: "+date1);
						 */

						Child c1 = new Child(lat, lon, battery, speed, ts);
						lst.add(c1);
					}// end of while
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				// ps1.close();
				// ps2.close();
				// ps3.close();
				// ps4.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			this.checkIn(con);
		}
		return lst;
	}

	// getting all safe lat,lon,radius to claculate zone
	public ArrayList<SafeZone> getSafeZoneLatLon(int cID) {
		String methodName = "getSafeZoneLatLon";

		logInfo(methodName, "entered with child id: " + cID);
		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;
		String query = "SELECT lat,lon,radius FROM mylocus.child_safezone WHERE (TIME(FROM_UNIXTIME(UNIX_TIMESTAMP())) BETWEEN TIME(stTS) AND TIME(enTS)) AND (DATE(FROM_UNIXTIME(UNIX_TIMESTAMP())) BETWEEN DATE(stTS) AND DATE(enTS)) AND cid=?";

		ArrayList<SafeZone> list = new ArrayList<SafeZone>();
		try {
			con = this.checkOut();
			ps = con.prepareStatement(query);
			ps.setInt(1, cID);
			// System.out.println(ps);
			rs = ps.executeQuery();
			while (rs.next() == true) {
				String lat = rs.getString("Lat");
				String lon = rs.getString("Lon");
				int radius = rs.getInt("Radius");
				// System.out.println(lat);
				SafeZone safezone = new SafeZone(cID, lat, lon, radius);
				list.add(safezone);
				// System.out.println(list.toString());
			}// end of while
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				// //ps.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			this.checkIn(con);
		}
		return list;
	}

	// adding safe zones
	public int addSafeZone(String cid, String lat, String lon, String radius,
			String stTS, String enTS) {
		String methodName = "addSafeZone";
		logInfo(methodName, "entered with child id: " + cid + ", lat: " + lat
				+ ", lon: " + lon + ", " + radius + ", start time: " + stTS
				+ ", end time: " + enTS);
		PreparedStatement ps = null;
		String query = "insert into mylocus.child_safezone(cID,Lat,Lon,Radius,stTS,enTS) values(?,?,?,?,?,?)";
		int i = 0;
		Connection con = null;
		// Calendar calendar = Calendar.getInstance();
		// java.sql.Timestamp date = new
		// java.sql.Timestamp(calendar.getTime().getTime());

		try {
			con = this.checkOut();
			if (con == null) {
				System.out.println("null conn");
			}
			ps = con.prepareStatement(query);
			ps.setString(1, cid);
			ps.setString(2, lat);
			ps.setString(3, lon);
			ps.setString(4, radius);
			ps.setString(5, stTS);
			ps.setString(6, enTS);
			System.out.println(ps);
			// System.out.println(query);
			i = ps.executeUpdate();
		} catch (Exception e) {

		} finally {
			this.checkIn(con);
		}
		return i;
	}

	// removing safe zone
	public int deleteSafeZone(String cid, String lat, String lon, String radius) {
		String methodName = "deleteSafeZone";
		logInfo(methodName, "entered with child id: " + cid);

		PreparedStatement ps = null;
		Connection con = null;
		int i = 0;
		String query = "DELETE FROM mylocus.child_safezone WHERE cID=? AND lat=? AND lon=? and radius=?";

		try {
			con = this.checkOut();
			ps = con.prepareStatement(query);
			ps.setString(1, cid);
			ps.setString(2, lat);
			ps.setString(3, lon);
			ps.setString(4, radius);

			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.checkIn(con);
		}
		return i;
	}

	// get all safe zones
	public ArrayList<SafeZone> getAllSafeZone(int cid) {
		String methodName = "getAllSafeZone";
		logInfo(methodName, "entered with child id: " + cid);
		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;
		String query = "SELECT lat,lon,radius FROM mylocus.child_safezone WHERE cid=?";

		ArrayList<SafeZone> list = new ArrayList<SafeZone>();
		try {
			con = this.checkOut();
			ps = con.prepareStatement(query);
			ps.setInt(1, cid);
			// System.out.println(ps);
			rs = ps.executeQuery();
			while (rs.next() == true) {
				String lat = rs.getString("Lat");
				String lon = rs.getString("Lon");
				int radius = rs.getInt("Radius");

				SafeZone safezone = new SafeZone(cid, lat, lon, radius);
				list.add(safezone);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				// ps.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			this.checkIn(con);
		}
		return list;
	}

	// get last lat,lon of child to calculate zone
	public Child getChildLastLatLon(int cid) {
		String methodName = "getChildLastLatLon";
		logInfo(methodName, "entered with cID: " + cid);
		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;

		Child child = null;
		String query = "SELECT lat,lon FROM mylocus.trackerlocation WHERE tid IN(SELECT tid FROM child WHERE cid=?) ORDER BY TS DESC LIMIT "
				+ LAST_LOCATION_LIMIT;
		try {
			con = this.checkOut();
			ps = con.prepareStatement(query);
			ps.setInt(1, cid);
			System.out.println(ps);
			rs = ps.executeQuery();
			while (rs.next() == true) {
				String lat = rs.getString("Lat");
				String lon = rs.getString("Lon");
				// System.out.println("lat=="+lat);
				// System.out.println("lon=="+lon);
				child = new Child(cid, lat, lon);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
			}
			this.checkIn(con);
		}
		return child;
	}

	// adding new user information (parent-child mapping)
	public ArrayList<String> addUser(String name1, String mobile1,
			String name2, String mobile2, String name3, String mobile3,
			String deviceNum, String imei, String pwd, String cName,
			String operator,String regId,String os) {
		String methodName = "addUser";
		logInfo(methodName, "entered with parent mobile: " + mobile1
				+ " parent name: " + name1 + " child mobile: " + deviceNum
				+ " imei no: " + imei + " password: " + pwd + " operator: "
				+ operator+" regId: "+regId+" os: "+os);

		java.sql.CallableStatement cs = null;
		Connection con = null;
		String response = "";
		String usermobile = "";
		String query1 = "{call adduser(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)} ";
		ArrayList<String> list = new ArrayList<String>();
		// String query2 =
		// "select @response as response,@parentinfo as parentinfo";
		try {
			con = this.checkOut();
			cs = con.prepareCall(query1);
			cs.setString(1, imei);
			cs.setString(2, deviceNum);
			cs.setString(3, mobile1);
			cs.setString(4, name1);
			cs.setString(5, mobile2);
			cs.setString(6, name2);
			cs.setString(7, mobile3);
			cs.setString(8, name3);
			cs.setString(9, pwd);
			cs.setString(10, cName);
			cs.setString(11, operator);
			cs.setString(12, regId);
			cs.setString(13, os);
			// cs.setString(10,response);
			// cs.setString(11,parentinfo);
			cs.registerOutParameter(14, java.sql.Types.VARCHAR);
			cs.registerOutParameter(15, java.sql.Types.VARCHAR);
			System.out.println(cs);
			cs.executeUpdate();
			response = cs.getString(14);
			usermobile = cs.getString(15);
			list.add(response);
			list.add(usermobile);
			// System.out.println("response="+response);
			// System.out.println("parentinfo="+usermobile);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// cs.close();

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.checkIn(con);
		}
		return list;
	}

	// change user password
	public String changePassword(String mobile, String old_pwd, String new_pwd) {
		String methodName = "changePassword";
		logInfo(methodName, "entered with mobile: " + mobile + " old pwd: "
				+ old_pwd + " new pwd: " + new_pwd);
		PreparedStatement ps = null;
		ResultSet rs = null;
		int i = 0;
		String oldpassword = null;
		String response = null;
		String query1 = "select pwd from mylocus.login_info where mobilenum = ?";
		String query2 = "update mylocus.login_info set pwd = ? where mobilenum = ? and pwd = ?";
		Connection con = null;
		try {
			con = this.checkOut();
			if (con == null) {
				System.out.println("null conn");
			}
			ps = con.prepareStatement(query1);
			ps.setString(1, mobile);
			System.out.println(ps);
			rs = ps.executeQuery();
			while (rs.next()) {
				oldpassword = rs.getString("pwd");
				System.out.println("old pwd: " + oldpassword);
			}
			if (oldpassword.equalsIgnoreCase(old_pwd)) {
				if (!old_pwd.equalsIgnoreCase(new_pwd)) {
					ps = con.prepareStatement(query2);
					ps.setString(1, new_pwd);
					ps.setString(2, mobile);
					ps.setString(3, old_pwd);
					System.out.println(ps);
					i = ps.executeUpdate();
				} else {
					response = "password is same as old password";
					logInfo(methodName, "password is same as old password");
				}
			} else {
				response = "old password was incorrect";
				logInfo(methodName, "old password was incorrect");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.checkIn(con);
		}
		if (i > 0) {
			response = "password updated successfully";
			logInfo(methodName, "password updated successfully for mobile no: "
					+ mobile);
		}
		// else{
		// response = "could not update password technical problem";
		// logInfo(methodName,"could not update password for mobile no: "+mobile);
		// }
		return response;
	}

	// to change emergency contact numbers
	public int changeNumber(String mobile1, String mobile2, String mobile3) {
		String methodName = "changeNumber";
		logInfo(methodName, "entered with mobile1: " + mobile1 + ", mobile2: "
				+ mobile2 + ", mobile3: " + mobile3);
		Connection con = null;
		PreparedStatement ps = null;
		int i = 0;
		String query1 = "UPDATE parent_info SET pMobile2 = ?,pMobile3 = ? WHERE pMobile1=?";
		String query2 = "UPDATE parent_info SET pMobile2 = ? WHERE pMobile1=?";
		String query3 = "UPDATE parent_info SET pMobile3 = ? WHERE pMobile1=?";

		try {
			con = this.checkOut();
			if (con == null) {
				System.out.println("null conn");
			}
			if (!mobile2.equals("") && !mobile3.equals("")) {
				ps = con.prepareStatement(query1);
				ps.setString(1, mobile2);
				ps.setString(2, mobile3);
				ps.setString(3, mobile1);
				System.out.println(ps);
				i = ps.executeUpdate();
			} else if (!mobile2.equals("")) {
				ps = con.prepareStatement(query2);
				ps.setString(1, mobile2);
				ps.setString(2, mobile1);
				System.out.println(ps);
				i = ps.executeUpdate();
			} else if (!mobile3.equals("")) {
				ps = con.prepareStatement(query3);
				ps.setString(1, mobile3);
				ps.setString(2, mobile1);
				System.out.println(ps);
				i = ps.executeUpdate();
			} else {
				System.out.println("mobile1 and mobile2 are null");
			}
			if (i > 0) {
				logInfo(methodName, "updated successfully");
			} else {
				logInfo(methodName, "failed to update");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.checkIn(con);
		}
		return i;
	}

	// adding new child (parent-child mapping)
	public ArrayList<String> addChild(String mobile1, String deviceNum,
			String imei, String cName, String operator) {
		String methodName = "addChild";
		logInfo(methodName, "entered with parent mobile: " + mobile1
				+ " child mobile: " + deviceNum + " imei no: " + imei
				+ " child name: " + cName + " operator: " + operator);

		java.sql.CallableStatement cs = null;
		Connection con = null;
		String response = "";
		String usermobile = "";
		String query = "{call addchild(?,?,?,?,?,?,?)} ";
		ArrayList<String> list = new ArrayList<String>();
		try {
			con = this.checkOut();

			cs = con.prepareCall(query);
			cs.setString(1, imei);
			cs.setString(2, deviceNum);
			cs.setString(3, mobile1);
			cs.setString(4, cName);
			cs.setString(5, operator);
			// cs.setString(10,response);
			// cs.setString(11,parentinfo);
			cs.registerOutParameter(6, java.sql.Types.VARCHAR);
			cs.registerOutParameter(7, java.sql.Types.VARCHAR);
			System.out.println(cs);
			cs.executeUpdate();
			response = cs.getString(6);
			usermobile = cs.getString(7);
			list.add(response);
			list.add(usermobile);
			System.out.println("response=" + response);
			System.out.println("parentinfo=" + usermobile);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				cs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.checkIn(con);
		}
		return list;
	}

	// to get list of country, operators and apn
	public ArrayList<APN> getAPN(String country, String operator) {

		String methodName = "getAPN";
		logInfo(methodName, "entered with country: " + country + " operator: "
				+ operator);

		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;
		String apn = "";
		String countries = "";
		String opertr = "";
		APN ap = null;
		ArrayList<APN> list = new ArrayList<APN>();

		String query1 = "SELECT distinct country FROM apn";
		String query2 = "SELECT operator FROM apn where country = ?";
		String query3 = "SELECT apn from apn where country = ? and operator  = ?";

		try {
			con = this.checkOut();

			if (country.equals("")) {
				ps = con.prepareStatement(query1);
				System.out.println(ps);
				rs = ps.executeQuery();
				while (rs.next() == true) {
					countries = rs.getString("country");
					logInfo(methodName, countries);
					ap = new APN(countries);
					list.add(ap);
				}
				if(list.size() == 0) {
					ap = new APN("Countries not found");
					list.add(ap);
				}
			} else if (operator.equals("")) {
				ps = con.prepareStatement(query2);
				ps.setString(1, country);
				System.out.println(ps);
				rs = ps.executeQuery();
				while (rs.next() == true) {
					opertr = rs.getString("operator");

					ap = new APN(country, opertr);
					list.add(ap);
				}
			} else if (!country.equals("") && !operator.equals("")) {
				ps = con.prepareStatement(query3);
				ps.setString(1, country);
				ps.setString(2, operator);
				System.out.println(ps);
				rs = ps.executeQuery();
				while (rs.next() == true) {
					apn = rs.getString("apn");

					ap = new APN(countries, opertr, apn);
					list.add(ap);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				// ps.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			this.checkIn(con);
		}
		return list;
	}

	// updating operator in trackerdevice table
	public int updateOperator(String cId, String operator) {

		String methodName = "updateOperator";
		logInfo(methodName, "entered with child id: " + cId + " operator: "
				+ operator);

		PreparedStatement ps = null;
		Connection con = null;
		int i = 0;

		String query = "UPDATE trackerdevice SET tOperator = ? WHERE tID IN(SELECT tID FROM child WHERE cID = ?)";

		try {
			con = this.checkOut();
			ps = con.prepareStatement(query);
			ps.setString(1, operator);
			ps.setString(2, cId);
			System.out.println(ps);
			i = ps.executeUpdate();

			if (i > 0) {
				logInfo(methodName,
						"updated operator successfully for child id: " + cId);
			} else {
				logInfo(methodName, "fail to update");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.checkIn(con);
		}
		return i;
	}

	// gettind location between two dates/time
	public ArrayList<Child> getLocationBetweenDates(int cid, String stDate,
			String enDate) {

		String methodName = "getLocationBetweenDates";
		logInfo(methodName, "entered with child id: " + cid + " stDate: "
				+ stDate + " enDate: " + enDate);

		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;
		String lat = "";
		String lon = "";
		String battery = "";
		String speed = "";
		String ts = null;
		ArrayList<Child> lst = new ArrayList<Child>();

		String query = "SELECT lat,lon,battery,speed,CONVERT_TZ(ts,'+00:00','+05:30') AS ts FROM trackerlocation"
				+ " WHERE ts >= CONVERT_TZ(?,'+00:00','-05:30') AND ts <= CONVERT_TZ(?,'+00:00','-05:30')"
				+ " AND tID IN(SELECT tID FROM child WHERE cID=?) ORDER BY TS DESC";
		try {
			con = this.checkOut();
			ps = con.prepareStatement(query);
			ps.setString(1, stDate);
			ps.setString(2, enDate);
			ps.setInt(3, cid);
			System.out.println(ps);
			rs = ps.executeQuery();

			while (rs.next() == true) {
				lat = rs.getString("Lat");
				lon = rs.getString("Lon");
				battery = rs.getString("Battery");
				speed = rs.getString("Speed");
				ts = rs.getString("TS");

				Child c1 = new Child(lat, lon, battery, speed, ts);
				lst.add(c1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			this.checkIn(con);
		}
		return lst;
	}

	// getting current location of device (ambulance service)
	public ArrayList<Ambulance> getCurrentLoc(String country) {
		String methodName = "getCurrentLoc";
		logInfo(methodName," entered with country: "+country);
		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;
		Ambulance amb = null;
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String query1 = "SELECT tid,licenseno FROM ambulance where country = ?";
		String query2 = "SELECT a.tid,a.licenseno,td.tmobilenumber,tl.lat,tl.lon,CONVERT_TZ(NOW(),'+00:00','+05:30') AS ts,licenseno FROM ambulance AS a INNER JOIN trackerdevice AS td ON td.tid = a.tid INNER JOIN trackerlocation AS tl ON tl.tid = td.tid WHERE a.tid = ? ORDER BY tl.ts DESC LIMIT "+LAST_LOCATION_LIMIT;
		ArrayList<Ambulance> lst = new ArrayList<Ambulance>();
		ArrayList<String> tId = new ArrayList<String>();
		try {
			con = this.checkOut();
			if (con == null) {
				System.out.println("null conn");
			}
			ps = con.prepareStatement(query1);
			ps.setString(1, country);
			System.out.println(ps);
			rs = ps.executeQuery();
			while (rs.next() == true) {
				tId.add(rs.getString("tId"));
			}
			
			for(int i=0;i<tId.size();i++){
				String trackerId = tId.get(i);
				ps = con.prepareStatement(query2);
				ps.setString(1, trackerId);
				System.out.println(ps);
				rs = ps.executeQuery();
				while (rs.next() == true) {
					String licenseNo = rs.getString("licenseno");	
					String tmobileNo = rs.getString("tmobilenumber");
					String lat = rs.getString("lat");
					String lon = rs.getString("lon");
					String ts = rs.getString("ts");
					System.out.println(ts);
				//	Date date = sdf.parse(ts);
					cal.setTime(sdf.parse(ts));
					int year = cal.get(Calendar.YEAR);
					int month = cal.get(Calendar.MONTH)+1;
					int day = cal.get(Calendar.DAY_OF_MONTH);
					int hr = cal.get(Calendar.HOUR_OF_DAY);
					Random randomI = new Random();
					int xPass = randomI.nextInt() % 7;
					System.out.println("xPass=="+xPass);
					int min = cal.get(Calendar.MINUTE)+xPass;
					int sec = cal.get(Calendar.SECOND);
					
					String stTs = year+"-"+month+"-"+day+" "+hr+":"+min+":"+sec;
					System.out.println(stTs);
					
					amb = new Ambulance(trackerId,licenseNo,tmobileNo,lat,lon,stTs);
					lst.add(amb);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				// ps.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			this.checkIn(con);
		}
		
		
		//iterator iamb = amb.iterator()
		//abulance a = amb.get(i);
		//
		
		return lst;
	}

	// Log using Logger at the INFO level
	public void logInfo(String methodName, String message) {
		logger.info(classname + "." + methodName + ":" + message);
	}

	// Log using Logger at the ERROR level
	public void logError(String methodName, String message) {
		logger.error(classname + "." + methodName + ":" + message);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DBManager db = DBManager.getInstance();
		// db.updateParent("", "9901400004", "9901400004", "", "", "", "", "",
		// "", "", "", "", "");
		// db.deleteParent("9901400004");
		//db.getChildLatLon(1);
		// db.getAllSafeZone(1);
		db.getCurrentLoc("India");
		db.release();
	}

}
