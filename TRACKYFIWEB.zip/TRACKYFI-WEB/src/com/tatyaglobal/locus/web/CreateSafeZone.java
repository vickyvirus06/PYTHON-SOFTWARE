package com.tatyaglobal.locus.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.tatyaglobal.locus.db.DBManager;

/**
 * Servlet implementation class CreateSafeZone
 */
@WebServlet("/CreateSafeZone")
public class CreateSafeZone extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String classname="CreateSafeZone";
	String methodname="AddSafeZone";
	
	private Logger logger =null;
	public void init(ServletConfig config)throws ServletException
	{
		logger=Logger.getRootLogger();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();

		String strOut = "";
	    int i = 0;
	    String startdate="";
		String enddate="";
		//reading safe zone parameters
		String cid=request.getParameter("cID");
		String lat=request.getParameter("Lat");
		String lon=request.getParameter("Lon");
		String radius=request.getParameter("Radius");
		String startTS=request.getParameter("stTime");
		String endTS=request.getParameter("enTime");
		
		String stTS = startTS.replace("_", " ");
		String enTS = endTS.replace("_", " ");
		
		DBManager cp = DBManager.getInstance();
		

		String[] startparts = stTS.split(" ");//splitting stTS to separate date and time 
		String[] endparts = enTS.split(" ");//splitting enTS to separate date and time 
			
		
		startdate=startparts[0];//storing start date to a variable
		String starttime=startparts[1];//storing start time to a variable
		    
		enddate=endparts[0];//storing end date to a variable 
		String endtime=endparts[1];//storing end time to a variable
			    
		//System.out.println("end date:"+enddate);
		//System.out.println("end time:"+endtime);
	
		Calendar st=Calendar.getInstance();
		Calendar en=Calendar.getInstance();
			   
		//if start date and end date is 0000-00-00 then assigning start date to curr date and end date to date after 1 year from curr date
		if((startdate.equals("0000-00-00"))&&(enddate.equals("0000-00-00")))
		{
			//System.out.println("start date & end date is null");
			st.add(Calendar.DATE, 0);//setting start date to current date 
			//System.out.println("st date:"+getDate(st));
			en.add(Calendar.YEAR,1);//setting end date to next year from currant date	    
			//System.out.println("en date:"+getDate(en));
			stTS=getDate1(st)+" "+starttime;
			enTS=getDate2(en)+" "+endtime;	     
		}     
		//if only start date is 0000-00-00 then assigning start date to a curr date
		else if(startdate.equals("0000-00-00")){
			//System.out.println("start date is null");
			st.add(Calendar.DATE, 0);
			//System.out.println("st date:"+getDate(st));
			stTS=getDate1(st)+" "+starttime;
		}     
		//if only end date is 0000-00-00 then assigning it to a date after 1 year from curr date
		else if(enddate.equals("0000-00-00"))
		{
			//System.out.println(" end date is null");	
			en.add(Calendar.YEAR,1);	    
			//System.out.println("en date:"+getDate(en));
			enTS=getDate2(en)+" "+endtime;	
		}else{
			stTS=startdate+" "+starttime;
			enTS=enddate+" "+endtime;	
		}    
		i = cp.addSafeZone(cid,lat,lon,radius,stTS,enTS);
		
		if(i>0){
			logInfo(methodname,"inserted successfully");
			strOut+="{\"Safe Zone\":" +"\"inserted successfully\"}";
		}else{
			logInfo(methodname,"not inserted");
			strOut+="{\"Safe Zone\":" +"\"not inserted\"}";
		}
		logInfo(methodname,"response= "+ strOut);
		pw.println(strOut);
	}

	public void logInfo(String methodname,String message)
	{
		logger.info(classname+"."+methodname+":"+message);
	}	
	public void logerror(String methodname,String message)
	{
		logger.error(classname+"."+methodname+":"+message);
	}

	public static String getDate1(Calendar st){
		return "" +st.get(Calendar.YEAR)+"-"+ (st.get(Calendar.MONTH)+1)+"-" + st.get(Calendar.DATE) ;
	}
	public static String getDate2(Calendar en){
		return "" +en.get(Calendar.YEAR)+"-"+ (en.get(Calendar.MONTH)+1)+"-" + en.get(Calendar.DATE) ;
	}

}
