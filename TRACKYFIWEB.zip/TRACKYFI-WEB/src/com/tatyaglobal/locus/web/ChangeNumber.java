package com.tatyaglobal.locus.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.tatyaglobal.locus.db.DBManager;

/**
 * Servlet implementation class ChangeNumber
 * to change emergency contact 2 and 3
 */
@WebServlet("/ChangeNumber")
public class ChangeNumber extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String classname="ChangeNumber";
	String methodName="changeNumber";
	
	private Logger logger =null;
	public void init(ServletConfig config)throws ServletException{
		logger=Logger.getRootLogger();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String strOut = "";
		String mobile1  = request.getParameter("mobile1");
		String mobile2  = request.getParameter("mobile2");
		String mobile3  = request.getParameter("mobile3");
		
		DBManager db = DBManager.getInstance();
		int update  = db.changeNumber(mobile1, mobile2, mobile3);
		strOut+="{\"response\":";
		if(update > 0 ){
			strOut+="\"updated successfully\"";
		}else{
			strOut+="\"not updated\"";
		}
		strOut+="}";
		logInfo(methodName,"response= "+ strOut);
		pw.println(strOut);	
	}
	public void logInfo(String methodName,String message)
	{
		logger.info(classname+"."+methodName+":"+message);
	}
	public void logerror(String methodname,String message)
	{
		logger.error(classname+"."+methodName+":"+message);
	}

}
