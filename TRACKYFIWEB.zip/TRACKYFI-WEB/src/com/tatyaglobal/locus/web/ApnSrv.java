package com.tatyaglobal.locus.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.tatyaglobal.locus.beans.APN;
import com.tatyaglobal.locus.db.DBManager;


/**
 * Servlet implementation class ApnSrv
 */
@WebServlet("/ApnSrv")
public class ApnSrv extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String classname="ApnSrv";
	String methodname="getAPN";
	
	private Logger logger =null;
	public void init(ServletConfig config)throws ServletException
	{
		logger=Logger.getRootLogger();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
	
		String country = "";
		String operator = "";
		
		if (request.getParameter("country") != null)
			country = request.getParameter("country");
		 
		if (request.getParameter("operator") != null)
			operator = request.getParameter("operator");
		
		DBManager cp=DBManager.getInstance();
		String strOut = "";
	
		if(country.equals("")){
			ArrayList<APN> apn  = cp.getAPN(country,operator);
			strOut+="{\"countries\":[";
			for(int i = 0;i<apn.size();i++){
				APN countries = apn.get(i);
				strOut+="\""+countries.getCountry()+"\"";
				
				if(i < apn.size()-1){
					strOut += ",";
				}
			}
			strOut+="]}";
		}else if(operator.equals("")){
			ArrayList<APN> apn  = cp.getAPN(country,operator);
			strOut+="{\"operators\":[";
			for(int i = 0;i<apn.size();i++){
				APN oper = apn.get(i);
				strOut+="\""+oper.getOperator()+"\"";
				
				if(i < apn.size()-1){
					strOut += ",";
				}
			}
			strOut+="]}";
		}else if(!country.equals("") && !operator.equals("")){
			ArrayList<APN> apn  = cp.getAPN(country,operator);
			strOut+="{\"apn\":\""+apn.get(0).getApn().toLowerCase()+"\"}";
		}else{
			
		}
		
		logInfo(methodname,"response= "+ strOut);
		pw.println(strOut);
	}
	public void logInfo(String methodName, String message){
		logger.info(classname+"."+methodName+":"+message);
	}
	
	public void logError(String methodName, String message){
		logger.error(classname+"."+methodName+":"+message);
	}

}
