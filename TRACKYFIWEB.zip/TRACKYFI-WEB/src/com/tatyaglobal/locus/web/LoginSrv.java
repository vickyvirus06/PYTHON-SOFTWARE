package com.tatyaglobal.locus.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.tatyaglobal.locus.beans.*;
import com.tatyaglobal.locus.db.DBManager;

/**
 * Servlet implementation class LoginSrv
 */
@WebServlet("/LoginSrv")
public class LoginSrv extends HttpServlet implements LocusConstants{
	private static final long serialVersionUID = 1L;

	public static String classname="LoginSrv";
	String methodname="getLoginDetails";
	
	private Logger logger =null;

	public void init(ServletConfig config)throws ServletException
	{
		logger=Logger.getRootLogger();
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		logger.info(request.getRemoteAddr());
		
		String mobile=request.getParameter("mobile");
		String pass=request.getParameter("pwd");
		
		// get an instance of the Database manager
		DBManager cp= DBManager.getInstance();
		Login login= null;
		
		//checking whether cp!=null then passing name and pass to getLloginDetails method 
		//if cp=null then it comes back to login.html page  
		if(cp != null){
			login = cp.getLoginDetails(mobile, pass);
			
		}else{
			logInfo(methodname,"ERROR !!! Could not get Connection to DATABASE.rout");
			//
			// Technical Problem, returning {"-11"} as response
			//
			pw.println("{\"ERROR\": \""+TECHNICAL_PROBLEM+"\"}");
			
			//pw.println("Technical Problem !! Please try again");
			//RequestDispatcher rd=request.getRequestDispatcher("login.html");
			//rd.include(request, response);
		}
		
		if(login == null){
			logInfo(methodname,"mobile no.="+mobile+  ",response= "+"failed");
			//
			// wrong username or password, returning {"-10"} as response
			//
			pw.println("{\"ERROR\": \""+INVALID_LOGIN+"\"}");
			
			//RequestDispatcher rd=request.getRequestDispatcher("login.html");
			//rd.include(request, response);

		}else{
			
			String pID=login.getUserID();
			String pMobile = login.getMobileNum();
			String pName = "";
			ArrayList<Child> children = cp.getChildDetails(pID);//get child details by passing parent id 
			
			String strOut="";
			
			strOut += "{\"Children\": [";
			for (int i = 0; i < children.size(); i++) {
				Child c = children.get(i);
				strOut+=c.jsonString2();
				strOut+= ",";// added to separate the zone information
				int cid = c.getcID();
			
				pName=c.getpName();
				//pMobile = c.getpMobile();
				//System.out.println(pName);
				//get the lat long for the child. descending order of lat longs
				// we are restricting ourselves to only the last value of lat-long
				
				Child child=cp.getChildLastLatLon(cid);//taking only last lat,long of the child 
				
				if(child!=null)
				{
					String child_lat=child.getLatitude();//taking child lat 
					String child_lon=child.getLongitude();//taking child long

					double lat1=Double.parseDouble(child_lat);//converting string to double
					double lon1=Double.parseDouble(child_lon);//converting string to double

					double distance = 0;
					int radius=0;
					
					ArrayList<SafeZone> safezone= cp.getSafeZoneLatLon(cid);	//taking safe lat,lon and checking whether child is within safezone at current time 
					//taking safe lat,lon,radius and comparing it with child lat,lon 
					if(safezone.size()>0)
					{
						logInfo(methodname,"found safe lat,lon,radius for child:"+cid);
						for(int j=0;j<safezone.size();j++){
							String safe_lat=safezone.get(j).getLat();     //taking safe lat  
							String safe_lon=safezone.get(j).getLon();     //taking safe long
							radius=safezone.get(j).getRadius();           //and radius to calculate zone 
						
							double lat2=Double.parseDouble(safe_lat);	  //converting string to double
							double lon2=Double.parseDouble(safe_lon);	  //converting string to double
					
							 double x1 = Math.toRadians(lat1);
						      double y1 = Math.toRadians(lon1);
						      
						      double x2 = Math.toRadians(lat2);
						      double y2 = Math.toRadians(lon2);
						      double sec1 = Math.sin(x1)*Math.sin(x2);
						      double dl=Math.abs(y1-y2);
						      double sec2 = Math.cos(x1)* Math.cos(x2);
						      //sec1,sec2,dl are in degree, need to convert to radians
						      double centralAngle = Math.acos(sec1+sec2*Math.cos(dl));
						      //Radius of Earth: 6378.1 kilometers
						      distance =  centralAngle * 6378.1;
						      System.out.println("The distance is " + distance+" kilometers.");
						      
						      distance = (distance / 0.001)/2;
						//radius=DEFAULT_RADIUS;	// set in TrackerConstant ... 500
						} //end of for loop	
						//claculating the distance between two la,longs ... if distance is less than radius then child is safe ,else child is unsafe
						if(distance<=radius){
							logInfo(methodname,"Safe");
							strOut+="\"Zone\":"+"\"Safe\"";	
						}else{	
							//System.out.println("unsafe");
							logInfo(methodname,"UnSafe");
							strOut+="\"Zone\":"+"\"UnSafe\"";
						}
					}else{
						logInfo(methodname,"could not find safe lat,lon,radius for child:"+cid);
						//System.out.println("unsafe");//if there is no safe lat,lon,radius so by default child will be unsafe
						logInfo(methodname,"UnSafe");
						strOut+="\"Zone\":"+"\"UnSafe\"";
					}
				}else{
					logInfo(methodname,"could not find lat,lon  for child:"+cid);
					//System.out.println("unsafe");//if there is no safe lat,lon,radius so by default child will be unsafe
					logInfo(methodname,"UnSafe");
					strOut+="\"Zone\":"+"\"UnSafe\"";
				}
				strOut+="}";
				if(i < children.size()-1){
					strOut += ",";
				}	
			}
			strOut += "],";
			strOut += "\"Parent\": {\"ParentID\": \""+pID +  "\", \"ParentMobileNum\": \""+ pMobile+"\",\"ParentName\": \""+ pName+  "\" }";
			strOut += "}";

			logInfo(methodname,"response= "+ strOut);
			pw.println(strOut);
			
			logInfo(methodname,"name="+ mobile+",utype="+"parent"+  ",response= "+"success");	
		}
	}
	public void logInfo(String methodName, String message){
		logger.info(classname+"."+methodname+":"+message);
	}

	public void logError(String methodName, String message){
		logger.error(classname+"."+methodname+":"+message);
	}

}
