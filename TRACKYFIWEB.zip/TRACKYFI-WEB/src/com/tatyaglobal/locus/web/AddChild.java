package com.tatyaglobal.locus.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.tatyaglobal.locus.db.DBManager;


/**
 * Servlet implementation class AddChild
 * for adding new child
 */
@WebServlet("/AddChild")
public class AddChild extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String classname="AddChild";
	String methodName="addChild";
	private Logger logger=null;

	public void init(ServletConfig config)throws ServletException{
		logger=Logger.getRootLogger();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		String mobile1 = request.getParameter("mobile");
		String deviceNum = request.getParameter("deviceNum");
		String imei = request.getParameter("imei");
		String cName = request.getParameter("cName");
		String operator = request.getParameter("operator");
		
		DBManager cp=DBManager.getInstance();
		ArrayList<String> res = cp.addChild(mobile1,deviceNum,imei,cName,operator);
		System.out.println(res);
		String result = null;
		String usermobile = null;
		if(res.size()>0){
		int i = 0;
		result  = res.get(0);
		usermobile = res.get(1);
		}
		System.out.println("usermobile:"+usermobile);
		
		System.out.println("response:"+result);
		String strOut = "";
		 
		strOut+="{\"response\":";
		if(result.equalsIgnoreCase("mapped already"))
		{
			logInfo(methodName,"Imei already mapped to some other no. and the no. is:"+usermobile);
			strOut+="\"imei num already mapped to some other num\",\"usermobile\":\""+usermobile+"\"";
		}
		else if(result.equalsIgnoreCase("mapped already to some other no."))
		{
			logInfo(methodName,"Imei already mapped to some other no.");
			strOut+="\"Failed to register since this Imei number has already mapped \"";
		}
		else if(result.equalsIgnoreCase("imei does not exists"))
		{
			logInfo(methodName,"Imei no. doesnt exists"); 
			strOut+="\"Imei number does not exists\"";	
		}
		else{
			logInfo(methodName,"Registered successfully");
			strOut+="\"Registration Success\"";	
		}
		strOut+="}";
		logInfo(methodName,"response= "+ strOut);
		pw.println(strOut);
		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	public void logInfo(String methodname,String message)
	{
		logger.info(classname+"."+methodname+":"+message);
	}
	public void logerror(String methodname,String message)
	{
		logger.error(classname+"."+methodname+":"+message);
	}
}
