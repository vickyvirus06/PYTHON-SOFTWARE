package com.tatyaglobal.locus.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.tatyaglobal.locus.beans.Child;
import com.tatyaglobal.locus.db.DBManager;

/**
 * Servlet implementation class ChildLocation
 */
@WebServlet("/ChildLocation")
public class ChildLocation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String classname="ChildLocation";
	String methodname="getLocationBetweenDates";
	
	private Logger logger =null;
	public void init(ServletConfig config)throws ServletException
	{
		logger=Logger.getRootLogger();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String strOut = "";
		
		String childID = request.getParameter("cID");
		String startDate = request.getParameter("stDate");
		String endDate = request.getParameter("enDate");
		int cid=Integer.parseInt(childID);
			
		String stDate = startDate.replace("_", " ");
		String enDate = endDate.replace("_", " ");
		
		DBManager cp=DBManager.getInstance();
	
		ArrayList<Child> child = cp.getLocationBetweenDates(cid,stDate,enDate);
				
		strOut += "{\"Locations\":[";
		for (int i = 0; i < child.size(); i++) {
			Child c = child.get(i);
			strOut+= c.jsonString3();
			if(i < child.size()-1){
				strOut += ",";
				}
		}
		strOut += "]}";
	
		logInfo(methodname,"response= "+ strOut);
		pw.println(strOut);
		
		
	}
	public void logInfo(String methodName, String message){
		logger.info(classname+"."+methodName+":"+message);
	}
	
	public void logError(String methodName, String message){
		logger.error(classname+"."+methodName+":"+message);
	}

}
