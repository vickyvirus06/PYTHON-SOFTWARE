package com.tatyaglobal.locus.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.tatyaglobal.locus.beans.SafeZone;
import com.tatyaglobal.locus.db.DBManager;

/**
 * Servlet implementation class SafeZoneSrv
 * to give all the safezones
 */
@WebServlet("/SafeZoneSrv")
public class SafeZoneSrv extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String classname="SafeZoneSrv";
	String methodname="getAllSafeZone";
	
	private Logger logger =null;
	public void init(ServletConfig config)throws ServletException
	{
		logger=Logger.getRootLogger();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
        
		String childID = request.getParameter("cID");
		int cid = Integer.parseInt(childID);
		
		DBManager cp=DBManager.getInstance();
		ArrayList<SafeZone> safezone=cp.getAllSafeZone(cid);
	
		String strOut = "";
		strOut += "{\"Safe\":[";
		for (int i = 0; i < safezone.size(); i++) {
			SafeZone safe = safezone.get(i);
			//System.out.println(c.toString());
			strOut+= safe.jsonString1();
			if(i < safezone.size()-1){
				strOut += ",";
			}
		}
		strOut += "]}";
		logInfo(methodname,"response= "+ strOut);
		pw.println(strOut);	
	}
	public void logInfo(String methodName, String message){
		logger.info(classname+"."+methodName+":"+message);
	}
	
	public void logError(String methodName, String message){
		logger.error(classname+"."+methodName+":"+message);
	}
}
