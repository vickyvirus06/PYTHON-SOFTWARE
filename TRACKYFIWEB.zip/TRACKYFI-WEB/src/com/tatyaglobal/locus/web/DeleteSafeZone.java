package com.tatyaglobal.locus.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.tatyaglobal.locus.db.DBManager;

/**
 * Servlet implementation class DeleteSafeZone
 */
@WebServlet("/DeleteSafeZone")
public class DeleteSafeZone extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String classname="DeleteSafeZone";
	String methodname="deleteSafeZone";
	
	private Logger logger =null;
	public void init(ServletConfig config)throws ServletException
	{
		logger=Logger.getRootLogger();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
        
		//reading safe zone parameters
		String cid=request.getParameter("cID");
		String lat=request.getParameter("Lat");
		String lon=request.getParameter("Lon");
		String radius=request.getParameter("Radius");
		
		DBManager cp=DBManager.getInstance();
		
		 int i = cp.deleteSafeZone(cid,lat,lon,radius);
		  
	  	  String strOut = "";
		  if(i>0){
			  logInfo(methodname,"deleted successfully");
			  strOut+="{\"Safe Zone\":" +"\"deleted successfully\"}";
		  }else {
			  logInfo(methodname,"not deleted");
			  strOut+="{\"Safe Zone\":" +"\"not deleted\"}";
		  }
		  logInfo(methodname,"response= "+ strOut);
		  pw.println(strOut);
		}

		public void logInfo(String methodname,String message)
		{
			logger.info(classname+"."+methodname+":"+message);
		}	
		public void logerror(String methodname,String message)
		{
			logger.error(classname+"."+methodname+":"+message);
		}
}
